##########################READ ME#############################################

This is a Rasa based chatbot which uses Zomato API to search for restaurants given the city , cuisine, average cost for two people and returns the result based on decreasing order of restaurants' ratings. This implementation recognizes all tier-1 and tier-2 cities and filter the response based on the budget with the help of custom actions. It even has an email functionality if chosen by the user.

A short working demo of the chatbot dynamics (entity recognition, slot selection etc) can be seen in this video:
https://drive.google.com/drive/folders/1vt0Z_PdkovuigPKbcKFMZ12ItjqVDGgc?usp=sharing

Stack:
tensorflow2.3.2
numpy1.9
rasa2.0.0
python3.7
anaconda
VScode

Files:

actions.py - contains custom functions for enhanced functionality
configuration.py - contains the pipelines (default pipeline for rasa2.0.0)
credentials.yml - contains the OAUTH token to slack bot
domain.yml - contains the universe/abstraction of all the entities, intents, actions etc used

training data:
nlu.yml - it contains 129 examples of 8 distinct intents along with 75 examples of 5 distinct entities
stories.yml - it contains the interactive 36 stories

testing data:
test.yml - as displayed in the video this contains test stories