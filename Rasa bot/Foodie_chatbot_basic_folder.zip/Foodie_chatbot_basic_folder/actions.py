from __future__ import absolute_import
from __future__ import division
from __future__ import unicode_literals
from __future__ import absolute_import
from __future__ import division
from __future__ import unicode_literals

from rasa_sdk import Action
from rasa_sdk.events import SlotSet
import zomatopy
import json
import pandas as pd
import smtplib, ssl
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

port = 465  # For SSL
smtp_server = "smtp.gmail.com"
sender_email = "rasarasa1729@gmail.com"  # Enter your address
receiver_email = "barkhasaxena02@gmail.com"  # Enter receiver address
password = "rAsa*1729"
message_html = """\
<!DOCTYPE html>
<html>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/3/w3.css">
<body>

    <section class="w3-container w3-center w3-content" style="max-width:600px">
	<h2>Here are the top 10 choices for {cuisine} restraunt in {location}:</h2>
     <ol>
    {res_list}
    </ol> 
    <br><br>

      </section>
      <div class="FozYP">
    </div>

</body>
</html>
"""
cuisines_dict={'bakery':5,'chinese':25,'cafe':30,'italian':55,'biryani':7,'north indian':50,'south indian':85}


class ActionSearchRestaurants(Action):
	def name(self):
		return 'action_search_restaurants'

	def filter_budget_friendly(self,budget,d):
		d_rated = []
		for restaurant in d['restaurants']:
			res = {}
			res["name"] = restaurant['restaurant']['name']
			res["loc"] = restaurant['restaurant']['location']['address']
			res["rating"] = restaurant['restaurant']['user_rating']['aggregate_rating']
			res["cost"] = restaurant['restaurant']['average_cost_for_two']
			res["avg_cost"] = restaurant['restaurant']['average_cost_for_two']
			d_rated.append(res)
		d_rated_df = pd.DataFrame.from_records(d_rated,index = 'cost')
		price_min = 0
		price_max = 99999
		if budget == "low":
			price_max = 300
		elif budget == "mid":
			price_min = 300
			price_max = 700
		elif budget == "high":
			price_min = 700

		#res = d_rated_df[price_min:price_max].sort_values(by="rating",ascending=False).head(5)
		res = d_rated_df[(d_rated_df['avg_cost']>=price_min )&(d_rated_df['avg_cost']<price_max )].sort_values(by="rating",ascending=False).head(5) 
		response = ""
		print("res list")
		print(res.head())
		if len(res) == 0:
			response = "Uh Oh! no restraunts found for this choice"
		else:
			for index, row in res.iterrows():
				stmnt = row['name']+" in " +row['loc'] +" has been rated "+str(row['rating'])+" with avg cost of Rs. "+str(row['avg_cost'])
				response = response +"\n" +stmnt
		return response
		
	def run(self, dispatcher, tracker, domain):
		config={ "user_key":"b70bc8c7e00f5682b463a0b320ac8886"}
		zomato = zomatopy.initialize_app(config)
		loc = tracker.get_slot('location')
		cuisine = tracker.get_slot('cuisine')
		budget = tracker.get_slot('budget')
		print(budget)
		location_detail=zomato.get_location(loc, 1)
		d1 = json.loads(location_detail)
		lat=d1["location_suggestions"][0]["latitude"]
		lon=d1["location_suggestions"][0]["longitude"]
		rating_suffix="&sort=rating&order=desc"
		results=zomato.restaurant_search("", lat, lon, str(cuisines_dict.get(cuisine)),rating_suffix, 20)
		d = json.loads(results)
		response=""		
		if budget is not None:
			print("filtering budget")
			response = self.filter_budget_friendly(budget,d)

		if d['results_found'] == 0:
			response= "no results"
		elif budget is None:
			print("no budget found")
			for i,restaurant in enumerate(d['restaurants']):
				if i > 5:
					break
				response=response+ "Found "+ restaurant['restaurant']['name']+ " in "+ restaurant['restaurant']['location']['address']+" with a rating of "+str(restaurant['restaurant']['user_rating']['aggregate_rating'])+"\n"
		
		dispatcher.utter_message("Here are the top 5 results:"+response)
		return [SlotSet('location',loc)]
class ActionEmailRestaurantList(Action):
	def name(self):
		return 'action_email_restaurants_list'

	def filter_budget_friendly(self,budget,d):
		d_rated = []
		for restaurant in d['restaurants']:
			res = {}
			res["name"] = restaurant['restaurant']['name']
			res["loc"] = restaurant['restaurant']['location']['address']
			res["rating"] = restaurant['restaurant']['user_rating']['aggregate_rating']
			res["cost"] = restaurant['restaurant']['average_cost_for_two']
			res["avg_cost"] = restaurant['restaurant']['average_cost_for_two']
			d_rated.append(res)
		d_rated_df = pd.DataFrame.from_records(d_rated,index = 'cost')
		price_min = 0
		price_max = 99999
		if budget == "low":
			price_max = 300
		elif budget == "mid":
			price_min = 300
			price_max = 700
		elif budget == "high":
			price_min = 700

		#res = d_rated_df[price_min:price_max].sort_values(by="rating",ascending=False).head(5)
		res = d_rated_df[(d_rated_df['avg_cost']>=price_min )&(d_rated_df['avg_cost']<price_max )].sort_values(by="rating",ascending=False).head(10) 
		response = ""
		print("res list")
		print(res.head())
		res_list=[]
		if len(res) == 0:
			response = "Uh Oh! no restraunts found for this choice"
			res_list =[]
		else:
			for index, row in res.iterrows():
				stmnt = row['name']+" in " +row['loc'] +" has been rated "+str(row['rating'])+" with avg cost of Rs. "+str(row['avg_cost'])
				res_list.append(stmnt)
				response = response +"\n" +stmnt
		return res_list		
	def get_list(self, dispatcher, tracker, domain):
		config={ "user_key":"b70bc8c7e00f5682b463a0b320ac8886"}
		zomato = zomatopy.initialize_app(config)
		loc = tracker.get_slot('location')
		cuisine = tracker.get_slot('cuisine')
		budget = tracker.get_slot('budget')
		location_detail=zomato.get_location(loc, 1)
		d1 = json.loads(location_detail)
		lat=d1["location_suggestions"][0]["latitude"]
		lon=d1["location_suggestions"][0]["longitude"]
		rating_suffix="&sort=rating&order=desc"
		results=zomato.restaurant_search("", lat, lon, str(cuisines_dict.get(cuisine)),rating_suffix, 20)
		d = json.loads(results)
		res_list =[]
		response=""
		if budget is not None:
			res_list = self.filter_budget_friendly(budget,d)

		if d['results_found'] == 0:
			response= "no results"
		elif budget is None:
			for restaurant in d['restaurants']:
				res_item = restaurant['restaurant']['name']+ " in "+ restaurant['restaurant']['location']['address']+" has been rated "+str(restaurant['restaurant']['user_rating']['aggregate_rating']) +" with average budget for 2 being Rs."+str(restaurant['restaurant']['average_cost_for_two'])+"\n"
				res_list.append(res_item)
				response=response+res_item
		
		
		return res_list

	def prepare_body(self,cuisine, location,res_list):
		list_body= ""
		template="<li>{item}</li>"

		for res in res_list:
			list_body = "\n".join([list_body,template.format(item=res)])
		html_body = message_html.format(res_list=list_body,cuisine=cuisine,location=location)
		# print(list_body)
		return html_body
	

	def send_email(self,cuisine, location,res_list,receiver_email):
		message = MIMEMultipart("alternative")
		message["Subject"] = "Top Restraunts from Foodie"
		message["From"] = sender_email
		message["To"] = receiver_email
		message_html = self.prepare_body(cuisine, location,res_list)
		part2 = MIMEText(message_html, "html")
		message.attach(part2)
		server = smtplib.SMTP_SSL('smtp.googlemail.com', 465)
		server.login(sender_email, password)
		server.sendmail(sender_email, receiver_email,message.as_string())
		server.quit()
		return "Pass"

	
	def run(self, dispatcher, tracker, domain):
		res_list =self.get_list( dispatcher, tracker, domain)
		location = tracker.get_slot('location')
		cuisine = tracker.get_slot('cuisine')
		email = tracker.get_slot('email')
		print(email)
		print(location)
		print(cuisine)
		msg=""
		resp = ""
		output = "Fail"
		code =0
		if len(res_list)==0:
			msg = "Uh Oh! no results found"
			output = "Fail"
			code = 404
		else:
			output = self.send_email(cuisine, location,res_list,email)
		if output == "Pass":
			print("Sent the mail")
			dispatcher.utter_message("The results have been mailed. Please check your email")
		else:
			print("Unable to send email")
			if code == 404:
				resp = msg
			else:
				resp = "Unable to send email. Please try again"
			dispatcher.utter_message(resp)
		return [SlotSet('email',email)]
	
